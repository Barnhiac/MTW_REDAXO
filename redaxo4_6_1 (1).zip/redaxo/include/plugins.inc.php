<?php

/**
 * Pluginlist
 * @package redaxo4
 * @version svn:$Id$
 */


// ----------------- DONT EDIT BELOW THIS
// --- DYN

    $REX['ADDON']['plugins']['be_style']['install']['agk_skin'] = '1';
    $REX['ADDON']['plugins']['be_style']['status']['agk_skin']  = '1';
            
// --- /DYN
// ----------------- /DONT EDIT BELOW THIS
