<?php

// ----------------- CLANG
// --- DYN
$REX['CLANG'] = array (
    0 => 'deutsch',
);
// --- /DYN
