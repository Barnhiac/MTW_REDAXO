<?php

/**
 * Backend Search Addon
 *
 * @author markus[dot]staab[at]redaxo[dot]de Markus Staab
 *
 * @package redaxo4
 * @version svn:$Id$
 */

?>
<h3>Backend Search Addon</h3>

<p>
Addon zur erweiterten und schnelleren Suche von Artikeln,
Kategorien und Medien im Backend.
</p>

<p>
Die Suchergebnisse beziehen sich immer auf die aktuell
ausgewählte Kategorie und deren Unterkategorien. Ausserdem werden
die Berechtigungen berücksichtigt
</p>
