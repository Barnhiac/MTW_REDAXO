<?php

/**
 * Backend Search Addon
 *
 * @author markus[dot]staab[at]redaxo[dot]de Markus Staab
 *
 * @package redaxo4
 * @version svn:$Id$
 */


$REX['ADDON']['install']['be_search'] = 0;
// ERRMSG IN CASE: $REX['ADDON']['installmsg']['be_search'] = "Deinstallation fehlgeschlagen weil...";
