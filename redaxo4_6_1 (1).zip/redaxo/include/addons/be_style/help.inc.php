<?php

/**
 * Backendstyle Addon
 *
 * @author jan.kristinus[at]redaxo[dot]de Jan Kristinus
 * @author <a href="http://www.yakamara.de">www.yakamara.de</a>
 *
 * @author markus[dot]staab[at]redaxo[dot]de Markus Staab
 * @author <a href="http://www.redaxo.de">www.redaxo.de</a>
 *
 * @package redaxo4
 * @version svn:$Id$
 */

?>
<h3>Backend Style Addon</h3>

<p>
Addon zum ver&auml;ndern der Optik des Backends
</p>
