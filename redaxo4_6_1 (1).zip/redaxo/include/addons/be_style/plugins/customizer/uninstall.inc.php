<?php

$error = '';
if ($error != '') {
    $REX['ADDON']['installmsg']['customizer'] = $error;
} else {
    $REX['ADDON']['install']['customizer'] = 0;
}
