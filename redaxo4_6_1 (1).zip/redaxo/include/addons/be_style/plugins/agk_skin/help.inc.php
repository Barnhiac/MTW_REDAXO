REDAXO Default-Theme
