<?php

/**
 * MetaForm Addon
 *
 * @author markus[dot]staab[at]redaxo[dot]de Markus Staab
 *
 *
 * @package redaxo4
 * @version svn:$Id$
 */

?>
<b>MetaForm Addon</b>

<br /><br />
Addon zur erweiterung der bestehenden Metadaten von Artikeln und Kategorien
