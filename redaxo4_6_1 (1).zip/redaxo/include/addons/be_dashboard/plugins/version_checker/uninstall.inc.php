<?php

/**
 * REDAXO Version Checker Addon
 *
 * @author markus[dot]staab[at]redaxo[dot]de Markus Staab
 * @author <a href="http://www.redaxo.de">www.redaxo.de</a>
 *
 * @package redaxo4
 * @version svn:$Id$
 */

$REX['ADDON']['install']['version_checker'] = 0;
// ERRMSG IN CASE: $REX['ADDON']['installmsg']['version_checker'] = "Deinstallation fehlgeschlagen weil...";
