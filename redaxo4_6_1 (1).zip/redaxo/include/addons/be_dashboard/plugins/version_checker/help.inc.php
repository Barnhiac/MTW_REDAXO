<?php

/**
 * REDAXO Version Checker Addon
 *
 * @author markus[dot]staab[at]redaxo[dot]de Markus Staab
 * @author <a href="http://www.redaxo.de">www.redaxo.de</a>
 *
 * @package redaxo4
 * @version svn:$Id$
 */

?>
<h3>REDAXO Version Checker Addon</h3>

<p>
Dieses Addon prueft, ob die aktuell installierte REDAXO Version aktuell ist.
Die Informationen werden über eine Dashboard-Komponente bereitgestellt.
</p>
