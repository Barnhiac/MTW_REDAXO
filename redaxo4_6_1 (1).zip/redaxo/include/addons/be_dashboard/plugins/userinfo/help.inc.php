<?php

/**
 * Userinfo Addon
 *
 * @author markus[dot]staab[at]redaxo[dot]de Markus Staab
 * @author <a href="http://www.redaxo.de">www.redaxo.de</a>
 *
 * @package redaxo4
 * @version svn:$Id$
 */

?>
<h3>Userinfo Addon</h3>

<p>
Dieses Addon praesentiert den Benutzern wichtige Informationen aus dem Backend.
Diese werden je nach Rolle/Rechten des Users aufbereitet.
Es wird zwischen Redakteuren und Administratoren unterschieden.
Die Informationen werden über eine Dashboard-Komponente bereitgestellt.
</p>
