<?php

/**
 * RSS Reader Addon
 *
 * @author markus[dot]staab[at]redaxo[dot]de Markus Staab
 * @author <a href="http://www.redaxo.de">www.redaxo.de</a>
 *
 * @package redaxo4
 * @version svn:$Id$
 */

?>
<h3>RSS Reader Addon</h3>

<p>
Dieses Addon liest RSS-Feeds von versch. Seiten ein und stellt diese im Backend dar.
Die Informationen werden über eine Dashboard-Komponente bereitgestellt.
</p>
