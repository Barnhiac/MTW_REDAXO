<?php

/**
 * RSS Reader Addon
 *
 * @author markus[dot]staab[at]redaxo[dot]de Markus Staab
 * @author <a href="http://www.redaxo.de">www.redaxo.de</a>
 *
 * @package redaxo4
 * @version svn:$Id$
 */

$REX['ADDON']['install']['rss_reader'] = 0;
// ERRMSG IN CASE: $REX['ADDON']['installmsg']['rss_reader'] = "Deinstallation fehlgeschlagen weil...";
