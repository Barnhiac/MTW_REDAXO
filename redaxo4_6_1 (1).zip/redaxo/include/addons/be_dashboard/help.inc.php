<?php

/**
 * Backenddashboard Addon
 *
 * @author markus[dot]staab[at]redaxo[dot]de Markus Staab
 * @author <a href="http://www.redaxo.de">www.redaxo.de</a>
 *
 * @package redaxo4
 * @version svn:$Id$
 */


?>
<h3>Backend Dashboard Addon</h3>

<p>
Dieses Addon praesentiert den Benutzern im Backend eine Startseite die im Stil eines Dashboards aufgebaut ist.
Addons koennen inhalte in das Dashboard einbringen und weiterhin koennen Plugins weitere Datenquellen darstellen.
</p>
