<?php

$REX['ADDON']['install']['import_export'] = 0;
// ERRMSG IN CASE: $REX['ADDON']['installmsg']['import_export'] = "Deinstallation fehlgeschlagen weil...";
