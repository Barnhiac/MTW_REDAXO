XForm for REDAXO Version 4.5
=============

AddOn to manage tables and forms for REDAXO CMS Version 4.5


Installation
-------

* Download and unzip
* Rename the unzipped folder from redaxo_xform to xform
* Move the folder to your REDAXO 4.5 System /redaxo/include/addons/
* Install and activate the addon xform and the plugins setup, manager, email in the REDAXO 4.5 backend
