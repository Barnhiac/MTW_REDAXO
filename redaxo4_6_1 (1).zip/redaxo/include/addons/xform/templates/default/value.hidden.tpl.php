<input type="hidden" name="<?php echo $this->getName() ?>" id="<?php echo $this->getHTMLId() ?>" value="<?php echo htmlspecialchars($this->getValue()) ?>" />
