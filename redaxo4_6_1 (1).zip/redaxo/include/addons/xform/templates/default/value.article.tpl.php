<div class="article" id="<?php echo $this->getHTMLId() ?>">
    <?php echo $article->getArticle() ?>
</div>
