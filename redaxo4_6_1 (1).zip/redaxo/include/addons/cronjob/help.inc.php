<?php

/**
 * Cronjob Addon
 *
 * @author gharlan[at]web[dot]de Gregor Harlan
 *
 * @package redaxo4
 * @version svn:$Id$
 */

?>
<h3>Cronjob Addon</h3>

<p>
Dieses Addon ermoeglicht es, Cronjobs in einem jeweils festgelegten Intervall ausfuehren zu lassen. Es gibt drei Standardtypen: "PHP-Code", "PHP-Callback" und "URL-Aufruf".
</p>
<p>
Addons und Plugins koennen weitere spezielle Typen zur Verfuegung stellen (Beispiel: Im-/Export-Addon fuer automatische Datenbank-Sicherungen).
</p>
