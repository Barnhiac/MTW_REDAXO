<?php

/**
 * Cronjob Addon - Plugin optimize_tables
 *
 * @author gharlan[at]web[dot]de Gregor Harlan
 *
 * @package redaxo4
 * @version svn:$Id$
 */

?>
<h3>Plugin Tabellen-Optimierung fuer Cronjob Addon</h3>

<p>
Dieses Plugin stellt einen Cronjob-Typ zur Verfuegung, der alle rex_* Tabellen in der DB optimiert.
</p>
