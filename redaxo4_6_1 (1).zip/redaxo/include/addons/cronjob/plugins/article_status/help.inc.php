<?php

/**
 * Cronjob Addon - Plugin article_status
 *
 * @author gharlan[at]web[dot]de Gregor Harlan
 *
 * @package redaxo4
 * @version svn:$Id$
 */

?>
<h3>Plugin Artikel-Status fuer Cronjob Addon</h3>

<p>
Dieses Plugin stellt einen Cronjob-Typ zur Verfuegung, der Artikel automatisch online (bzw. offline) schaltet, wenn das in den Meta Infos eingestellte "Online von"-Datum (bzw. "Online bis") erreicht wurde.
</p>
