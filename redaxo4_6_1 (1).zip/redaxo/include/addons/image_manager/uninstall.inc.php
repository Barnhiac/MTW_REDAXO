<?php

/**
 * image_manager Addon
 *
 * @author office[at]vscope[dot]at Wolfgang Hutteger
 * @author <a href="http://www.vscope.at">www.vscope.at</a>
 *
 * @author markus[dot]staab[at]redaxo[dot]de Markus Staab
 *
 *
 * @package redaxo4
 * @version svn:$Id$
 */


$REX['ADDON']['install']['image_manager'] = 0;
// ERRMSG IN CASE: $REX['ADDON']['installmsg']['image_manager'] = "Deinstallation fehlgeschlagen weil...";
