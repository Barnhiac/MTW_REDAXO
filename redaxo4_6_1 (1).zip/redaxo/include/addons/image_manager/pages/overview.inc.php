<div class="rex-addon-output">
    <h2 class="rex-hl2">Image Manager Addon (Version <?php echo $REX['ADDON']['version']['image_manager'] ?>)</h2>
    <div class="rex-addon-content">
        <?php require dirname(__FILE__) . '/../help.inc.php'; ?>
    </div>
</div>
