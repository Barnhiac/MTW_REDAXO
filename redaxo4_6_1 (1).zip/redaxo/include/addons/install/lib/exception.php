<?php

class rex_install_functional_exception extends Exception {}
