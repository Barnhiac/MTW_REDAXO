<?php

$REX['ADDON']['install']['install'] = false;
