<?php

/**
 * Textile Addon
 *
 * @author markus[dot]staab[at]redaxo[dot]de Markus Staab
 *
 * @package redaxo4
 * @version svn:$Id$
 */

?>
<p>
Bringt die Möglichkeit in Modulen Textile Markup zu verwenden

<br /><br />

<?php
    $file = dirname( __FILE__) . '/_changelog.txt';
    if (is_readable($file)) {
        echo str_replace( '+', '&nbsp;&nbsp;+', nl2br(file_get_contents($file)));
    }
?>
</p>
